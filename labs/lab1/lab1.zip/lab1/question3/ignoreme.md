![ignore me](https://assets.midnightcheese.com/gifs/ignore-me.gif)


#To do list for the day
1. Do absolutely nothing
2. eat lunch
3. wash dishes
4. exist (waste oxygen)
5. play with birb
6. ~~evil sleep~~ bedtime

## shopping spree
* scraps
* parts
* crisps
* chips
* ssd for $$$900

+ walgreens
+ green beans
+ cabbage

- Ramune